package ioc;

public interface IB {

	public void f1() ;

}
