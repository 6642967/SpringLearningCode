package scope;

public class ExampleBean {

	public ExampleBean() {
		System.out.println("LoveBean()");
	}

	public void init() {
		System.out.println("init()");
	}
	
	public void destroy() {
		System.out.println("destroy()");
	}
}
