package scope;

public class ScopeBean {

	public ScopeBean() {
		System.out.println("ScopeBean()");
	}

}
