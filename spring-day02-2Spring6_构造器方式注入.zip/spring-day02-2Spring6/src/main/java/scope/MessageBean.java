package scope;

public class MessageBean {

	public MessageBean() {
		System.out.println("MessageBean()");
	}
	//获取发送消息的目的地，通过初始化方法获取资源
	public void init() {
		System.out.println("init()");
	}
	
	
	//添加发送消息的方法
	public void sendMsg() {
		System.out.println("sendMsg() ");
	}
	
	public void destory() {
		System.out.println("destory()");
	}	
	
	//添加销毁方法
	public void destroy() {
		System.out.println("destroy()");
	}
}
