package ioc2;

public class A {

	private B b;
	
	public A() {
		System.out.println("A()");
	}
	
	//添加有参构造器
	public A(B b) {
		System.out.println("A(B)");
		//super(); 可以不要
		this.b = b;
	}

	public void execute() {
		System.out.println("execute()");
		//添加对象b的方法f1的引用
		b.f1();
	}

}
