package ioc2;

public class B {

	public B() {
		System.out.println("B()");
	}
	
	public void f1() {
		System.out.println("B's f1()");
	}

}
