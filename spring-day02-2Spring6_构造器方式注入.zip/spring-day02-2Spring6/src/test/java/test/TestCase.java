package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import ioc.A;
import scope.ExampleBean;
import scope.MessageBean;
import scope.ScopeBean;

public class TestCase {

	@Test
	//测试作用域
	public void test1() {
		//启动Spring容器
		ApplicationContext ac=
				new ClassPathXmlApplicationContext("scope.xml");
		//获得对象
		ScopeBean s1=
				ac.getBean("s1", ScopeBean.class);
		//获得对象
		ScopeBean s2=
				ac.getBean("s1", ScopeBean.class);
		System.out.println(s1==s2);
	}
	
	@Test
	//测试生命周期
	public void test2() {
/**		
 * //启动Spring容器
		ApplicationContext ac=
	new ClassPathXmlApplicationContext(
			"scope.xml");
		//获得对象
		MessageBean mb1=
		ac.getBean("mb1", MessageBean.class);
		mb1.sendMsg();
*/		
		//！！！关闭容器（使用aac不是ac了）
		//ApplicationContext:接口
		//AbstractApplicationContext：子接口，实现了关闭容器的close方法
		//ClassPathXmlApplicationContext
		//实现了上述接口具体类
		AbstractApplicationContext aac=
				new ClassPathXmlApplicationContext(
						"scope.xml"); 
		MessageBean mb1 = aac.getBean("mb1", MessageBean.class);
		mb1.sendMsg();
		//关闭容器
		aac.close();
	}
	
	@Test
	public void test3() {
		ApplicationContext ac=
			new ClassPathXmlApplicationContext(
					"scope.xml");
		//此方法中没有使用getBean()方法
	}
	
	@Test
	public void test4() {
		//ApplicationContext ac=
//	new ClassPathXmlApplicationContext(
//			"scope.xml");
//		ExampleBean eb=
//			ac.getBean("eb1",ExampleBean.class);
		//eb.init();
		//eb.destroy();
	}
	
	@Test//测试set方式的注入
	public void test5() {
		ApplicationContext ac=
			new ClassPathXmlApplicationContext(
					"ioc.xml");
		A a1= 
				ac.getBean("a1", A.class);
		a1.execute();
	}
}
