package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import ioc2.A;

public class TestCase2 {
	@Test
	public void test1() {
		ApplicationContext ac=
		new ClassPathXmlApplicationContext(
						"ioc2.xml");
		A a1=
				ac.getBean("a1",A.class);
		a1.execute();
	}

}
